"""
URL configuration for config project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import include, path


urlpatterns = [

    # ==========================================
    # DJANGO ADMIN
    # ==========================================

    path(
        'admin/',
        admin.site.urls
    ),


    # ==========================================
    # ACCOUNTS APP
    # ==========================================

    path(
        '',
        include('accounts.urls')
    ),


    # ==========================================
    # PATIENT APP
    # ==========================================

    path(
        'patient/',
        include('patients.urls')
    ),
    # ==========================================
    # DOCTOR APP
    # ==========================================
    path(
        'doctor/',
        include('doctors.urls')
    ),
    path('appointments/', include('appointments.urls')),
    # ==========================================
    # PRESCRIPTION URLS
    # ==========================================    
    path('prescriptions/', include('prescriptions.urls')),
    # ==========================================
    # MEDICAL RECORD URLS
    # ==========================================
    path('medical-records/', include('medical_records.urls')),
    path('billing/', include('billing.urls')),
    

]